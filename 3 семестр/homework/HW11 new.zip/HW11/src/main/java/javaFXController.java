import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class javaFXController {

    @FXML
    private Pane mainPane;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private MenuItem ch_cost;

    @FXML
    private MenuItem ch_num;

    @FXML
    private MenuItem ch_type;

    @FXML
    private MenuItem ch_year;

    @FXML
    private TableColumn<?, ?> cost;

    @FXML
    private TableColumn<?, ?> dt;

    @FXML
    private TableColumn<?, ?> id;

    @FXML
    private PieChart pieChart;

    @FXML
    private TableColumn<?, ?> serviceType;

    @FXML
    private TableView<?> table;

    @FXML
    private TableColumn<?, ?> trainN;

    @FXML
    public void initialize() {
        assert ch_cost != null : "fx:id=\"ch_cost\" was not injected: check your FXML file 'Untitled'.";
        assert ch_num != null : "fx:id=\"ch_num\" was not injected: check your FXML file 'Untitled'.";
        assert ch_type != null : "fx:id=\"ch_type\" was not injected: check your FXML file 'Untitled'.";
        assert ch_year != null : "fx:id=\"ch_year\" was not injected: check your FXML file 'Untitled'.";
        assert cost != null : "fx:id=\"cost\" was not injected: check your FXML file 'Untitled'.";
        assert dt != null : "fx:id=\"dt\" was not injected: check your FXML file 'Untitled'.";
        assert id != null : "fx:id=\"id\" was not injected: check your FXML file 'Untitled'.";
        assert pieChart != null : "fx:id=\"pieChart\" was not injected: check your FXML file 'Untitled'.";
        assert serviceType != null : "fx:id=\"serviceType\" was not injected: check your FXML file 'Untitled'.";
        assert table != null : "fx:id=\"table\" was not injected: check your FXML file 'Untitled'.";
        assert trainN != null : "fx:id=\"trainN\" was not injected: check your FXML file 'Untitled'.";

    }

    public static void initApp(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = FXMLLoader.load(javaFXController.class.getResource("javaFX.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 650, 270);

        stage.setTitle("Classifieur");
        stage.setScene(scene);
        //  stage.setResizable(false);
        stage.show();
    }
}
