import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.Arrays;

public class MainFX extends Application {

    static String propName = "id";
    static String order = "ASCENDING";

    public VBox tableBox;
    public Pane mainPane;
    public MenuButton menuButton;
    public MenuItem ch_year;
    public MenuItem ch_type;
    public MenuItem ch_num;
    public MenuItem ch_cost;
    public PieChart pieChart;

    static HBox labelsBox = new HBox();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("javaFX.fxml"));
        primaryStage.setTitle("Pie chart with table");
        primaryStage.setScene(new Scene(root, 880, 550));
        primaryStage.setResizable(false);
        initialize();
        initTable();
        primaryStage.show();
    }

    public void initTable() {
        // Создание подписей столбцов
        var col1 = new Button("ID ↑");
        col1.setOnAction(e -> Ordering(col1, "id"));
        var col2 = new Button("Дата -");
        col2.setOnAction(e -> Ordering(col2, "dt"));
        var col3 = new Button("Тип сервиса -");
        col3.setOnAction(e -> Ordering(col3, "serviceType"));
        var col4 = new Button("Номер состава -");
        col4.setOnAction(e -> Ordering(col4, "trainN"));
        var col5 = new Button("Стоимость -");
        col5.setOnAction(e -> Ordering(col5, "cost"));
        labelsBox.setSpacing(5);
        for (var col : Arrays.asList(col1, col2, col3, col4, col5)) {
            col.setMinWidth(110);
            col.setAlignment(Pos.CENTER);
        }
        labelsBox.setAlignment(Pos.TOP_RIGHT);
        labelsBox.getChildren().addAll(col1, col2, col3, col4, col5);

        tableBox.getChildren().addAll(labelsBox);

        // Создание таблицы
        createTable();
    }

    public void createTable() {
        VBox spreadsheet = new VBox();
        for (var servicing : Main.getServicingList(propName, order)) {
            HBox rowBox = new HBox();
            rowBox.setAlignment(Pos.TOP_LEFT);
            rowBox.setSpacing(5);

            var props = servicing.getAllProp();
            String id = props.get(0).toString();

            Button delButton = new Button("Удалить");
            delButton.setOnAction(e -> {
                Main.delete(id);
                createTable();
            });
            delButton.setMinWidth(70);
            rowBox.getChildren().add(delButton);

            for (var attr : props) {
                var cell = new TextField(attr.toString());
                cell.setOnKeyPressed(event -> {
                    if (event.getCode() == KeyCode.ENTER) {
                        oldEvents.updateService(cell);
                    }
                });
                cell.setMinWidth(110);
                cell.setMaxWidth(110);
                cell.setMinHeight(20);
                rowBox.getChildren().add(cell);
            }

            rowBox.setMaxWidth(515);
            spreadsheet.getChildren().add(rowBox);
        }
        try {
            tableBox.getChildren().remove(1);
        } catch (
                Exception e) {
            System.out.println(e);
        } finally {
            tableBox.getChildren().add(spreadsheet);
        }

    }

    public void Ordering(Button col, String prop) {
        String oldText = col.getText();
        String chr = "↑";
        if (propName.equals(prop)) {
            if (order.equals("ASCENDING")) {
                order = "DESCENDING";
                chr = "↓";
            } else {
                order = "ASCENDING";
            }
        } else {
            propName = prop;
            order = "ASCENDING";
        }

        var labels = labelsBox.getChildren();
        for (int i = 0; i<5; i++) {
            Button button = (Button) labels.get(i);
            String buttonText = button.getText();
            buttonText = buttonText.substring(0, buttonText.length()-1) + "-";
            button.setText(buttonText);
        }
        col.setText(oldText.substring(0, oldText.length()-1) + chr);
        createTable();
    }

    @FXML
    public void initialize() {
        assert ch_cost != null : "fx:id=\"ch_cost\" was not injected: check your FXML file 'Untitled'.";
        assert ch_num != null : "fx:id=\"ch_num\" was not injected: check your FXML file 'Untitled'.";
        assert ch_type != null : "fx:id=\"ch_type\" was not injected: check your FXML file 'Untitled'.";
        assert ch_year != null : "fx:id=\"ch_year\" was not injected: check your FXML file 'Untitled'.";
        assert pieChart != null : "fx:id=\"pieChart\" was not injected: check your FXML file 'Untitled'.";
    }
}
